# Installs the TranscriptMetaAnalyst release used for this analysis and checks
# that the installed package versions match those of the original run
# (session_info.txt). Run once, before analysis.R:  Rscript setup.R

recorded_r <- "4.6.1"
if (getRversion() < "4.5.0") stop("TranscriptMetaAnalyst needs R 4.5.0 or later; this is R ", getRversion(), ".")
if (getRversion() != recorded_r) {
  message("Note: the analysis was run with R ", recorded_r, "; this is R ", getRversion(), ".")
}

if (!requireNamespace("BiocManager", quietly = TRUE)) install.packages("BiocManager")
tma_version <- "2.1.0"
installed <- tryCatch(as.character(packageVersion("TranscriptMetaAnalyst")), error = function(e) NA)
if (!identical(installed, tma_version)) {
  BiocManager::install(paste0("Eabdelsalam/TranscriptMetaAnalyst@v", tma_version), update = FALSE, ask = FALSE)
}

# package versions of the original run
recorded <- c(abind = "1.4-8", aisdk = "1.4.12", annotate = "1.90.0", AnnotationDbi = "1.74.0", ape = "5.8-1", aplot = "0.3.2", assertthat = "0.2.1", Biobase = "2.72.0", BiocGenerics = "0.58.1", BiocParallel = "1.46.0", Biostrings = "2.80.2", bit = "4.6.0", bit64 = "4.8.6", blob = "1.3.0", brio = "1.1.5", ca = "0.72", cachem = "1.1.0", callr = "3.8.0", circlize = "0.4.18", cli = "3.6.6", clue = "0.3-68", cluster = "2.1.8.2", clusterProfiler = "4.20.3", codetools = "0.2-20", colorspace = "2.1-4", compiler = "4.6.1", ComplexHeatmap = "2.28.0", crayon = "1.5.3", data.table = "1.18.6.1", DBI = "1.3.0", DelayedArray = "0.38.2", dendextend = "1.19.1", desc = "1.4.3", DESeq2 = "1.52.0", devtools = "2.5.2", digest = "0.6.39", doParallel = "1.0.17", DOSE = "4.6.0", dplyr = "1.2.1", DT = "0.34.0", edgeR = "4.10.7", ellipsis = "0.3.3", EnhancedVolcano = "1.30.0", enrichit = "0.2.6", enrichplot = "1.32.1", farver = "2.1.2", fastmap = "1.2.0", fontBitstreamVera = "0.1.1", fontLiberation = "0.1.0", fontquiver = "0.2.1", foreach = "1.5.2", fs = "2.1.0", future = "1.80.0", gdtools = "0.5.2", genefilter = "1.94.0", generics = "0.1.4", GenomicRanges = "1.64.0", GEOquery = "2.80.0", GetoptLong = "1.1.1", ggforce = "0.5.0", ggfun = "0.2.2", ggiraph = "0.9.6", ggnewscale = "0.5.2", ggplot2 = "4.0.3", ggplotify = "0.1.4", ggrepel = "0.9.8", ggtangle = "0.1.4", ggtree = "4.2.0", ggvenn = "0.1.19", GlobalOptions = "0.1.4", globals = "0.20.0", glue = "1.8.1", GO.db = "3.23.1", GOSemSim = "2.38.3", grid = "4.6.1", gridExtra = "2.3.1", gridGraphics = "0.5-1", gson = "0.2.2", gtable = "0.3.6", heatmaply = "1.6.0", hms = "1.1.4", htmltools = "0.5.9", htmlwidgets = "1.6.4", httpuv = "1.6.17", httr = "1.4.9", httr2 = "1.3.0", igraph = "2.3.4", IRanges = "2.46.0", iterators = "1.0.14", jsonlite = "2.0.0", KEGGREST = "1.52.2", labeling = "0.4.3", later = "1.4.8", lattice = "0.23-1", lazyeval = "0.2.3", lifecycle = "1.0.5", limma = "3.68.5", listenv = "1.1.0", locfit = "1.5-9.12", magrittr = "2.0.5", MASS = "7.3-66", Matrix = "1.7-6", MatrixGenerics = "1.24.0", matrixStats = "1.5.0", memoise = "2.0.1", metaRNASeq = "1.0.8", mgcv = "1.9-4", mime = "0.13", nlme = "3.1-171", otel = "0.2.0", parallel = "4.6.1", parallelly = "1.48.0", patchwork = "1.3.2", pheatmap = "1.0.13", pillar = "1.11.1", pkgbuild = "1.4.8", pkgconfig = "2.0.3", pkgload = "1.5.3", plotly = "4.12.1", plyr = "1.8.9", png = "0.1-9", polyclip = "1.10-7", processx = "3.9.0", promises = "1.5.0", ps = "1.9.3", purrr = "1.2.2", qvalue = "2.44.0", R6 = "2.6.1", ragg = "1.5.2", rappdirs = "0.3.4", rbioapi = "0.8.3", RColorBrewer = "1.1-3", Rcpp = "1.1.2", readr = "2.2.0", registry = "0.5-1", rentrez = "1.2.4", reshape2 = "1.4.5", rjson = "0.2.23", rlang = "1.3.0", rprojroot = "2.1.1", RSQLite = "3.53.3", rstudioapi = "0.19.0", S4Arrays = "1.12.1", S4Vectors = "0.50.3", S7 = "0.2.2", scales = "1.4.0", scatterpie = "0.2.6", Seqinfo = "1.2.0", seriation = "1.6.0", sessioninfo = "1.2.4", shape = "1.4.6.1", shiny = "1.14.0", shinyalert = "3.1.0", shinycssloaders = "1.1.0", shinydashboard = "0.7.3", shinyjs = "2.1.1", SparseArray = "1.12.3", splines = "4.6.1", statmod = "1.5.2", stats4 = "4.6.1", stringi = "1.8.9", stringr = "1.6.0", SummarizedExperiment = "1.42.0", survival = "3.8-12", sva = "3.60.0", systemfonts = "1.3.2", testthat = "3.3.2", textshaping = "1.0.5", tibble = "3.3.1", tidydr = "0.0.7", tidyr = "1.3.2", tidyselect = "1.2.1", tidytree = "0.4.8", tools = "4.6.1", TranscriptMetaAnalyst = "2.1.0", treeio = "1.36.1", TSP = "1.2.7", tweenr = "2.0.3", tzdb = "0.5.0", usethis = "3.2.2", vctrs = "0.7.3", viridis = "0.6.5", viridisLite = "0.4.3", webshot = "0.5.5", withr = "3.0.3", XML = "3.99-0.25", xml2 = "1.6.0", xtable = "1.8-8", XVector = "0.52.0", yaml = "2.3.12", yulab.utils = "0.2.5", zip = "3.0.2")
now <- vapply(names(recorded), function(p) {
  tryCatch(as.character(packageVersion(p)), error = function(e) "not installed")
}, character(1))
differ <- now != recorded
if (any(differ)) {
  message(sum(differ), " package(s) differ from the original run (results may differ slightly):")
  print(data.frame(package = names(recorded)[differ], recorded = recorded[differ],
                   installed = now[differ], row.names = NULL))
} else {
  message("All ", length(recorded), " packages match the original run.")
}
